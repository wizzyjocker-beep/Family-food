FAMILY FOOD — site vitrine / menu digital

Fichiers:
- index.html : contenu du site
- style.css : design responsive
- script.js : filtres et bouton français/arabe

Publication sur Vercel:
1. Décompressez ce dossier.
2. Créez un compte GitHub et un nouveau dépôt (repository) public ou privé.
3. Téléversez index.html, style.css et script.js à la racine du dépôt.
4. Sur https://vercel.com, connectez-vous avec GitHub.
5. Add New -> Project, choisissez le dépôt, puis Deploy.
6. Vercel vous donnera une adresse publique.

À personnaliser AVANT de partager:
- Remplacez les exemples de plats et les prix « À définir » dans index.html.
- Ajoutez votre vrai numéro WhatsApp / adresse / horaires dans la section Contact.
- Remplacez l'adresse e-mail de démonstration contact@familyfood.example par votre contact réel.
- Les images actuelles sont des illustrations emoji; vous pourrez les remplacer par vos propres photos.

Aucun framework ni commande de build n'est nécessaire: c'est un site statique.
